function connectivity_analyses_cluster()

ROIdir='/group/duncan-lab/users/az01/task_switch2/DataAnalysis/ROIs_connectivity';
rois=cellstr(spm_select('List',ROIdir,'.*.nii'));
rois=rois([1,3,4,5,2]);
ROInames=regexprep(rois,'.nii','');
nr=length(rois);
ROIxyz=cell(1,nr);
outdir=fullfile('/group/duncan-lab/users/az01/task_switch2/DataAnalysis','Connectivity_analysis');
if ~exist(outdir,'dir'), mkdir(outdir); end

datadir='/group/duncan-lab/users/az01/task_switch2/DataAnalysis/aa5_analysis_030323_unsmoothed_GLMs/connectivity/aamod_firstlevel_model_00006/CBU230072/stats';
load(fullfile(datadir,'SPM.mat'));

for r=1:nr
    localroi=fullfile(outdir,rois{r});
    if ~exist(localroi,'file')
        copyfile(fullfile(ROIdir,rois{r}),localroi);
        spm_reslice(char(fullfile(datadir,'beta_0001.nii'),localroi),struct('which',1,'mean',0,'prefix','')); % reslice to any data file, here taken from decoding analysis's cfg structure
    end
    V=spm_vol(localroi); % load file header
    Y=spm_read_vols(V)>0.5; % load data from file, and binarise
    [x,y,z]=ind2sub(size(Y),find(Y)); % find coordinates of voxels in ROI
    ROIxyz{r}=[x y z]'; % store the coordinates in a cell array
    fprintf('.')
end
clear Y x y z

%load data
%outdir=fullfile('Z:\Duncan-lab\users\az01\task_switch2\DataAnalysis\Connectivity_analysis','data.mat');
% if ~exist(outdir,'file')
%
%
%
%     datadir='Z:\Duncan-lab\users\az01\task_switch2\DataAnalysis\aa5_analysis_030323_unsmoothed_GLMs\connectivity\aamod_firstlevel_model_00006';
%     allFiles = dir(datadir); allNames = { allFiles.name }; subNames = allNames(find(contains(allNames, 'CBU')));
%     %subname='CBU230072'; %subname=subnames{s}
%     data=nan(numel(subNames),nr,);
%     for s = 1:36
%         subdir=fullfile(datadir,subNames{s},'stats');
%
%         for r=1:nr %for each ROI
%             %collapsed within each condition
%             data(s,r,:)=nanmean(spm_get_data(fullfile(subdir,cellfun(@(l) sprintf('beta_%04d.nii', l), num2cell(1:744),'UniformOutput',false)),ROIxyz{r}),2);
%         end
%         fprintf('.')
%     end
%
%     save('data','data')
% else
%     load(outdir);
%     fprintf('Loaded subject data.')
% end
%aap=load('/group/duncan-lab/users/az01/task_switch2/DataAnalysis/aa5_analysis_030323/aap_parameters.mat');
%d={aap.aap.acq_details.subjects.subjname};
cnames={'task_stay','within_domain','between_domain','between_chunk','restart','rest_'};
for c = 1:numel(cnames) ROIdata.(cnames{c})=cell(5,1); end
all_comp.domain = {'two', 'four'};
all_comp.group_learnt = {'first', 'second'};type= fieldnames(all_comp);
%fieldn={'two', 'four','first', 'second'};
for d=1:2
    for g=1:2
        anovam.(all_comp.domain{d}).(all_comp.group_learnt{g})=cell(nr,1);
    end
end
subCorr=nan(36,3,numel(cnames));
pcc_ampfc_anovam=nan(36,2,2,2);
core_md_anovam =nan(36,2,2,2);
core_behav_anovam =nan(36,2,2,2);

datadir='/group/duncan-lab/users/az01/task_switch2/DataAnalysis/aa5_analysis_030323_unsmoothed_GLMs/connectivity/aamod_firstlevel_model_00006';
allFiles = dir(datadir); allNames = { allFiles.name }; subNames = allNames(find(contains(allNames, 'CBU')));
%subname='CBU230072'; %subname=subnames{s}
load('/group/duncan-lab/users/az01/task_switch2/DataAnalysis/allsub_rt.mat');
load('/group/duncan-lab/users/az01/task_switch2/DataAnalysis/allsub_trialname.mat');
fprintf('Loading subject data');
for s = 1:36
    subdir=fullfile(datadir,subNames{s},'stats');
    load(fullfile(subdir,'SPM.mat'));
    sub_behav_data=allsub_rt{s};
    %for each sub; loop through subnames starting with CBU
    %for s =1:numel(subnames)
    % for s=1:36
    % subdir=fullfile(datadir,subNames{s},'stats');
    for c = 1:numel(cnames) % for each condition
        for r=1:(nr-1) %for each ROI
            %collapsed within each condition
            
            ROIdata.(cnames{c}){r}=nanmean(spm_get_data(fullfile(subdir,cellfun(@(l) sprintf('beta_%04d.nii', l), num2cell(find(contains(SPM.xX.name,[' ' cnames{c}]))),'UniformOutput',false)),ROIxyz{r}),2);
            rt_rows=find(startsWith(allsub_trialname{s},cnames{c}));
            
            if r==1
                %global
                ROIdata.(cnames{c}){5}=nanmean(spm_get_data(fullfile(subdir,cellfun(@(l) sprintf('beta_%04d.nii', l), num2cell(find(contains(SPM.xX.name,[' ' cnames{c}]))),'UniformOutput',false)),ROIxyz{5}),2);
            end
            %sub_behav_data(c)=subdata(s,find(contains(SPM.xX.name,cnames{c})));
            %ROIdata.(cnames{c}){r}=data(:,r,find(contains(SPM.xX.name,[' ' cnames{c}])));
            
            if c==2 || c==3 % for wd and bd
                
                for graph = 1:2
                    domain = all_comp.domain{graph};
                    for g=1:2
                        group=all_comp.group_learnt{g};
                        num_rows=find(contains(SPM.xX.name,[' ' cnames{c}]).*contains(SPM.xX.name,domain).*contains(SPM.xX.name,group));
                        anovam.(domain).(group){r}=nanmean(spm_get_data(fullfile(subdir,cellfun(@(l) sprintf('beta_%04d.nii', l), num2cell(num_rows),'UniformOutput',false)),ROIxyz{r}),2);
                        
                        if r==1
                            anovam.(domain).(group){5}=nanmean(spm_get_data(fullfile(subdir,cellfun(@(l) sprintf('beta_%04d.nii', l), num2cell(num_rows),'UniformOutput',false)),ROIxyz{5}),2);
                        end
                            
                    end
                end
            end
            
            
        end
        
        subCorr(s,1,c)=partialcorr(ROIdata.(cnames{c}){1},ROIdata.(cnames{c}){4},ROIdata.(cnames{c}){5}); %PCC vs amPFC
        subCorr(s,2,c)=partialcorr(ROIdata.(cnames{c}){2},ROIdata.(cnames{c}){3},ROIdata.(cnames{c}){5}); %Core vs MD
        subCorr(s,3,c)=partialcorr(ROIdata.(cnames{c}){2},sub_behav_data(rt_rows)',ROIdata.(cnames{c}){5}); %Core vs RT
        if c==2 || c==3
            for graph=1:2
                domain = all_comp.domain{graph};
                for g=1:2
                    group=all_comp.group_learnt{g};
                    behav_rows=find(startsWith(allsub_trialname{s},cnames{c}).*contains(allsub_trialname{s},domain).*contains(allsub_trialname{s},group));
                    
                    pcc_ampfc_anovam(s,c-1,graph,g)=partialcorr(anovam.(domain).(group){1},anovam.(domain).(group){4},anovam.(domain).(group){5});%PCC amPFC
                    core_md_anovam(s,c-1,graph,g)=partialcorr(anovam.(domain).(group){2},anovam.(domain).(group){3},anovam.(domain).(group){5});%Core vs MD
                    core_behav_anovam(s,c-1,graph,g)=partialcorr(anovam.(domain).(group){2},sub_behav_data(behav_rows)',anovam.(domain).(group){5}); %Core vs behav
                end
            end
        end
        
    end
    fprintf('.');
end
subCorr=atanh(subCorr);
save('GR_fisher_subCorr','subCorr');
save('GR_pcc_ampfc_anovam','pcc_ampfc_anovam');
save('GR_core_md_anovam','core_md_anovam');
save('GR_core_behav_anovam','core_behav_anovam');

titles={'PCC VS amPFC Correlation values','Core DMN VS MD Correlation values','Core DMN activity VS RT Correlation values'};
%for every connectivity analysis
for con=1:3
    
    figdata=squeeze(subCorr(:,con,:)); %sub x cond
    
    [h,p,ci,stat]=ttest(figdata);
    unvbar=mean(figdata);
    error=abs(ci-repmat(mean(figdata),2,1));
    figure(con+1);clf(con+1);b=bar(unvbar);hold on;
    b.FaceColor = 'flat';
    
    orange=[239,138,71]; color1=orange/255;
    paleyellow=[255,208,111];color2=paleyellow/255;
    lightblue=[55,103,149];
    blue=[114,188,213];darkblue=[30,70,110]; color3=[blue;lightblue;darkblue];
    
    % Change the color of a specific bar (e.g., the second bar)
    b.CData(1, :) = color1; %[255/255 242/255 204/255]; % RGB color value
    b.CData(2, :) = color2; %[177/255 208/255 149/255]; % RGB color value
    b.CData(3:5,:)=color3/255; %repmat(color3,3,1);%[224/255 234/255 246/255]
    scatter(reshape(repmat(1:6,36,1),36*6,1),reshape(figdata,36*6,1),15,'k','MarkerEdgeAlpha',0.3);
    ebar=errorbar(1:6,unvbar,error(1,:),error(2,:),'k');
    ebar.LineStyle='none';box off;
    labname=regexprep(cnames(),'_','-');
    labname{2}= ['within-group-\newline' labname{2}];
    labname{3}= ['within-group-\newline' labname{3}];
    labname{4}='between-group-\newlinebetween-domain';
    set(gca,'xticklabel',labname);
    ylabel(titles{con});
    
    [h,p,ci,stat]=ttest(figdata(:,1),mean(figdata(:,2:5),2)); %against task stay
    fprintf('\nt-test for averaged task switch conditions compared to task repeats.\nt=%.3f,p=%.3f,BF=%.3e',stat.tstat,p,t1smpbf(stat.tstat,36));
    
    [h,p,ci,stat]=ttest(mean(figdata(:,1:5),2),figdata(:,6)); %against rest
    fprintf('\nt-test for averaged task switch conditions compared to rest.\nt=%.3f,p=%.3f,BF=%.3e',stat.tstat,p,t1smpbf(stat.tstat,36));
    
    [h,p,ci,stat]=ttest(figdata(:,3),figdata(:,4)); %between-domain-within-chunk compared to between-domain-between-chunk
    fprintf('\nt-test for between-domain-within-chunk compared to between-domain-between-chunk.\nt=%.3f,p=%.3f,BF=%.3e',stat.tstat,p,t1smpbf(stat.tstat,36));
    
    [h,p,ci,stat]=ttest(figdata(:,2),figdata(:,3)); %wd and bd
    fprintf('\nt-test for within-domain compared to between-domain-within-chunk.\nt=%.3f,p=%.3f,BF=%.3e',stat.tstat,p,t1smpbf(stat.tstat,36));
    
    [h,p,ci,stat]=ttest(figdata(:,5),figdata(:,2)); %restart and wd
    fprintf('\nt-test for restart compared to within-domain.\nt=%.3f,p=%.3f,BF=%.3e',stat.tstat,p,t1smpbf(stat.tstat,36));
    
    [h,p,ci,stat]=ttest(figdata(:,5),figdata(:,3)); %restart and bd
    fprintf('\nt-test for restart compared to to between-domain-within-chunk.\nt=%.3f,p=%.3f,BF=%.3e',stat.tstat,p,t1smpbf(stat.tstat,36));
    
    [h,p,ci,stat]=ttest(figdata(:,5),figdata(:,4)); %restart and bgbd
    fprintf('\nt-test for restart compared to between-domain-between-chunk.\nt=%.3f,p=%.3f,BF=%.3e\n',stat.tstat,p,t1smpbf(stat.tstat,36));
    
end

return